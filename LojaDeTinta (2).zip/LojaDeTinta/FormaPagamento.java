class FormaPagamento {

    private String tipo;


    public FormaPagamento(String tipo) {
        this.tipo = tipo;
    }

    // Getters e Setters
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}