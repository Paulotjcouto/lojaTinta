import java.util.Scanner;

public class LojaDeTinta {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Criando produtos de tinta
        Produto tintaBranca = new Produto("Tinta Branca", 50.0, 10);
        Produto tintaPreta = new Produto("Tinta Preta", 45.0, 5);
        Produto tintaAzul = new Produto("Tinta Azul", 40.0, 8);
        Produto tintaVerde = new Produto("Tinta Verde", 55.0, 7);
        Produto tintaAmarela = new Produto("Tinta Amarela", 60.0, 12);
        Produto tintaVermelha = new Produto("Tinta Vermelha", 35.0, 6);
        Produto tintaRoxa = new Produto("Tinta Roxa", 50.0, 10);
        Produto tintaLaranja = new Produto("Tinta Laranja", 45.0, 15);
        Produto tintaCinza = new Produto("Tinta Cinza", 40.0, 9);
        Produto tintaMarrom = new Produto("Tinta Marrom", 50.0, 8);
        Produto tintaRosa = new Produto("Tinta Rosa", 55.0, 6);
        Produto tintaBege = new Produto("Tinta Bege", 60.0, 11);
        Produto tintaLilas = new Produto("Tinta Lilás", 50.0, 10);
        Produto tintaDourada = new Produto("Tinta Dourada", 70.0, 7);
        Produto tintaPrateada = new Produto("Tinta Prateada", 75.0, 5);
        Produto tintaTurquesa = new Produto("Tinta Turquesa", 65.0, 8);
        Produto tintaMagenta = new Produto("Tinta Magenta", 55.0, 9);

        // Criando produtos de utensílios
        Produto pincel = new Produto("Pincel", 15.0, 20);
        Produto roloDePintura = new Produto("Rolo de Pintura", 25.0, 10);
        Produto fitaCrepe = new Produto("Fita Crepe", 5.0, 30);
        Produto bandejaDePintura = new Produto("Bandeja de Pintura", 12.0, 15);
        Produto espatula = new Produto("Espátula", 8.0, 25);

        // Criando estoque e adicionando produtos
        Estoque estoque = new Estoque();
        estoque.adicionarProduto(tintaBranca);
        estoque.adicionarProduto(tintaPreta);
        estoque.adicionarProduto(tintaAzul);
        estoque.adicionarProduto(tintaVerde);
        estoque.adicionarProduto(tintaAmarela);
        estoque.adicionarProduto(tintaVermelha);
        estoque.adicionarProduto(tintaRoxa);
        estoque.adicionarProduto(tintaLaranja);
        estoque.adicionarProduto(tintaCinza);
        estoque.adicionarProduto(tintaMarrom);
        estoque.adicionarProduto(tintaRosa);
        estoque.adicionarProduto(tintaBege);
        estoque.adicionarProduto(tintaLilas);
        estoque.adicionarProduto(tintaDourada);
        estoque.adicionarProduto(tintaPrateada);
        estoque.adicionarProduto(tintaTurquesa);
        estoque.adicionarProduto(tintaMagenta);
        estoque.adicionarProduto(pincel);
        estoque.adicionarProduto(roloDePintura);
        estoque.adicionarProduto(fitaCrepe);
        estoque.adicionarProduto(bandejaDePintura);
        estoque.adicionarProduto(espatula);

        // Criando cliente
        Cliente cliente = new Cliente();
        cliente.setNome("João");
        cliente.setCpf("12345678901");
        cliente.setEndereco("Rua Exemplo, 123");
        cliente.setTelefone("987654321");

        // Criando vendedor
        Vendedor vendedor = new Vendedor();
        vendedor.setNome("Maria");
        vendedor.setCpf("98765432100");
        vendedor.setIdFuncionario("V001");
        vendedor.setComissao(10.0);

        // Criando carrinho
        Carrinho carrinho = new Carrinho();

        // Iniciando a interface gráfica
        TelaPrincipal telaPrincipal = new TelaPrincipal(carrinho, estoque);
        telaPrincipal.setVisible(true);
    }
}
