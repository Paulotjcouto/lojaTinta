import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrincipal extends JFrame {
    private Carrinho carrinho;
    private Estoque estoque;

    public TelaPrincipal(Carrinho carrinho, Estoque estoque) {
        this.carrinho = carrinho;
        this.estoque = estoque;

        setTitle("Vitrine de Produtos");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Define esquema de cores
        Color backgroundColor = new Color(60, 63, 65);
        Color panelColor = new Color(43, 43, 43);
        Color textColor = new Color(187, 187, 187);
        Color buttonColor = new Color(75, 110, 175);
        Color buttonTextColor = Color.WHITE;

        // Configurações do título
        JLabel titulo = new JLabel("Vitrine de Produtos", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(textColor);
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Configurações do painel de produtos
        JPanel panelProdutos = new JPanel();
        panelProdutos.setLayout(new GridLayout(0, 4, 15, 15));
        panelProdutos.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelProdutos.setBackground(backgroundColor);

        // Adicione aqui os produtos disponíveis
        Produto[] produtos = new Produto[]{
                new Produto("Tinta Branca", 50.0, 10),
                new Produto("Tinta Preta", 45.0, 5),
                new Produto("Tinta Azul", 40.0, 8),
                new Produto("Tinta Verde", 55.0, 7),
                new Produto("Tinta Amarela", 60.0, 12),
                new Produto("Tinta Vermelha", 35.0, 6),
                new Produto("Tinta Roxa", 50.0, 10),
                new Produto("Tinta Laranja", 45.0, 15),
                new Produto("Tinta Cinza", 40.0, 9),
                new Produto("Tinta Marrom", 50.0, 8),
                new Produto("Tinta Acrílica", 15.0, 50),
                new Produto("Tinta Óleo", 20.0, 30),
                new Produto("Pincel", 5.0, 100),
                new Produto("Paleta", 10.0, 40),
                new Produto("Tela de Pintura", 25.0, 20),
                new Produto("Lápis de Cor", 12.0, 60),
                new Produto("Borracha", 2.0, 80),
                new Produto("Aquarela", 18.0, 35),
                new Produto("Carvão", 8.0, 70),
                new Produto("Esponja", 4.0, 90)
        };

        for (Produto produto : produtos) {
            JPanel panelProduto = new JPanel(new BorderLayout());
            panelProduto.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
            panelProduto.setBackground(panelColor);

            JLabel labelNome = new JLabel(produto.getNome());
            labelNome.setHorizontalAlignment(SwingConstants.CENTER);
            labelNome.setFont(new Font("Arial", Font.BOLD, 14));
            labelNome.setForeground(textColor);
            panelProduto.add(labelNome, BorderLayout.NORTH);

            JLabel labelPreco = new JLabel("Preço: R$ " + produto.getPreco());
            labelPreco.setHorizontalAlignment(SwingConstants.CENTER);
            labelPreco.setForeground(textColor);
            panelProduto.add(labelPreco, BorderLayout.CENTER);

            JButton buttonAdicionar = new JButton("Adicionar ao Carrinho");
            buttonAdicionar.setBackground(buttonColor);
            buttonAdicionar.setForeground(buttonTextColor);
            buttonAdicionar.setFocusPainted(false);
            buttonAdicionar.setBorder(BorderFactory.createLineBorder(buttonColor));
            buttonAdicionar.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    adicionarItemCarrinho(produto);
                }
            });
            panelProduto.add(buttonAdicionar, BorderLayout.SOUTH);

            panelProdutos.add(panelProduto);
        }

        JScrollPane scrollPane = new JScrollPane(panelProdutos);
        add(scrollPane, BorderLayout.CENTER);

        JButton buttonCarrinho = new JButton("Ver Carrinho");
        buttonCarrinho.setBackground(buttonColor);
        buttonCarrinho.setForeground(buttonTextColor);
        buttonCarrinho.setFocusPainted(false);
        buttonCarrinho.setBorder(BorderFactory.createLineBorder(buttonColor));
        buttonCarrinho.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirCarrinho();
            }
        });
        add(buttonCarrinho, BorderLayout.SOUTH);

        // Define o background da tela principal
        JPanel backgroundPanel = new JPanel(new BorderLayout());
        backgroundPanel.setBackground(backgroundColor);
        backgroundPanel.add(titulo, BorderLayout.NORTH);
        backgroundPanel.add(scrollPane, BorderLayout.CENTER);
        backgroundPanel.add(buttonCarrinho, BorderLayout.SOUTH);

        add(backgroundPanel);

        // Centraliza a tela
        setLocationRelativeTo(null);
    }

    private void adicionarItemCarrinho(Produto produto) {
        // Simula adição de um item ao carrinho
        int quantidade = 1; // Quantidade fixa para simplificação
        carrinho.adicionarItem(new ItemVenda(produto, quantidade));
        JOptionPane.showMessageDialog(this, produto.getNome() + " adicionado ao carrinho.");
    }

    private void abrirCarrinho() {
        // Abre a tela de carrinho
        TelaCarrinho telaCarrinho = new TelaCarrinho(carrinho, estoque);
        telaCarrinho.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Estoque estoque = new Estoque();
                // Adicione produtos ao estoque
                estoque.adicionarProduto(new Produto("Tinta Branca", 50.0, 10));
                estoque.adicionarProduto(new Produto("Tinta Preta", 45.0, 5));
                estoque.adicionarProduto(new Produto("Tinta Azul", 40.0, 8));
                estoque.adicionarProduto(new Produto("Tinta Verde", 55.0, 7));
                estoque.adicionarProduto(new Produto("Tinta Amarela", 60.0, 12));
                estoque.adicionarProduto(new Produto("Tinta Vermelha", 35.0, 6));
                estoque.adicionarProduto(new Produto("Tinta Roxa", 50.0, 10));
                estoque.adicionarProduto(new Produto("Tinta Laranja", 45.0, 15));
                estoque.adicionarProduto(new Produto("Tinta Cinza", 40.0, 9));
                estoque.adicionarProduto(new Produto("Tinta Marrom", 50.0, 8));
                estoque.adicionarProduto(new Produto("Tinta Acrílica", 15.0, 50));
                estoque.adicionarProduto(new Produto("Tinta Óleo", 20.0, 30));
                estoque.adicionarProduto(new Produto("Pincel", 5.0, 100));
                estoque.adicionarProduto(new Produto("Paleta", 10.0, 40));
                estoque.adicionarProduto(new Produto("Tela de Pintura", 25.0, 20));
                estoque.adicionarProduto(new Produto("Lápis de Cor", 12.0, 60));
                estoque.adicionarProduto(new Produto("Borracha", 2.0, 80));
                estoque.adicionarProduto(new Produto("Aquarela", 18.0, 35));
                estoque.adicionarProduto(new Produto("Carvão", 8.0, 70));
                estoque.adicionarProduto(new Produto("Esponja", 4.0, 90));

                Carrinho carrinho = new Carrinho();
                TelaPrincipal telaPrincipal = new TelaPrincipal(carrinho, estoque);
                telaPrincipal.setVisible(true);
            }
        });
    }
}




