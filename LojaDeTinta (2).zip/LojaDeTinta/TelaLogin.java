import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaLogin extends JFrame {
    private JTextField textFieldUsuario;
    private JPasswordField passwordFieldSenha;

    public TelaLogin() {
        setTitle("Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Define esquema de cores
        Color backgroundColor = new Color(60, 63, 65);
        Color panelColor = new Color(43, 43, 43);
        Color textColor = new Color(187, 187, 187);
        Color buttonColor = new Color(75, 110, 175);
        Color buttonTextColor = Color.WHITE;

        // Configurações do título
        JLabel titulo = new JLabel("Login", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(textColor);
        titulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(titulo, BorderLayout.NORTH);

        // Configurações do painel de login
        JPanel panelLogin = new JPanel();
        panelLogin.setLayout(new GridLayout(3, 2, 10, 10));
        panelLogin.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelLogin.setBackground(panelColor);

        JLabel labelUsuario = new JLabel("Usuário:");
        labelUsuario.setForeground(textColor);
        textFieldUsuario = new JTextField();
        textFieldUsuario.setBackground(Color.DARK_GRAY);
        textFieldUsuario.setForeground(textColor);
        textFieldUsuario.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JLabel labelSenha = new JLabel("Senha:");
        labelSenha.setForeground(textColor);
        passwordFieldSenha = new JPasswordField();
        passwordFieldSenha.setBackground(Color.DARK_GRAY);
        passwordFieldSenha.setForeground(textColor);
        passwordFieldSenha.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        panelLogin.add(labelUsuario);
        panelLogin.add(textFieldUsuario);
        panelLogin.add(labelSenha);
        panelLogin.add(passwordFieldSenha);

        // Configurações do botão de login
        JButton buttonLogin = new JButton("Login");
        buttonLogin.setBackground(buttonColor);
        buttonLogin.setForeground(buttonTextColor);
        buttonLogin.setFocusPainted(false);
        buttonLogin.setBorder(BorderFactory.createLineBorder(buttonColor));
        buttonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = textFieldUsuario.getText();
                char[] senhaChars = passwordFieldSenha.getPassword();
                String senha = new String(senhaChars);

                // Simula validação de usuário e senha (substitua por sua lógica real)
                if (usuario.equals("admin") && senha.equals("123")) {
                    JOptionPane.showMessageDialog(null, "Login realizado com sucesso!");
                    TelaPrincipal telaPrincipal = new TelaPrincipal(new Carrinho(), new Estoque());
                    telaPrincipal.setVisible(true);
                    dispose(); // Fecha a tela de login
                } else {
                    JOptionPane.showMessageDialog(null, "Usuário ou senha incorretos. Tente novamente.");
                    textFieldUsuario.setText("");
                    passwordFieldSenha.setText("");
                }
            }
        });

        // Adiciona o botão ao painel de login
        panelLogin.add(new JLabel());  // Placeholder para espaçamento
        panelLogin.add(buttonLogin);

        // Define o background da tela de login
        JPanel backgroundPanel = new JPanel(new BorderLayout());
        backgroundPanel.setBackground(backgroundColor);
        backgroundPanel.add(panelLogin, BorderLayout.CENTER);

        add(backgroundPanel);

        // Centraliza a tela
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TelaLogin telaLogin = new TelaLogin();
                telaLogin.setVisible(true);
            }
        });
    }
}


