public class FinalizandoCompra {
    public static void finalizarCompra(Carrinho carrinho, Estoque estoque) {
        for (ItemVenda item : carrinho.getItens()) {
            Produto produto = item.getProduto();
            int quantidadeComprada = item.getQuantidade();
            estoque.atualizarEstoque(produto, quantidadeComprada);
        }
        carrinho.getItens().clear();
    }
}
