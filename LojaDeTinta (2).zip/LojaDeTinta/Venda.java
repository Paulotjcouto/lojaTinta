import java.util.ArrayList;
import java.util.List;
class Venda {
    private Cliente cliente;
    private Vendedor vendedor;
    private List<ItemVenda> itens;
    private double total;

    public Venda(Cliente cliente, Vendedor vendedor) {
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.itens = new ArrayList<>();
        this.total = 0;
    }

    // Adiciona item à venda
    public void adicionarItem(ItemVenda item) {
        itens.add(item);
        total += item.getTotal();
    }

    // Getters e Setters
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public List<ItemVenda> getItens() {
        return itens;
    }

    public void setItens(List<ItemVenda> itens) {
        this.itens = itens;
    }

    public double getTotal() {
        return total;
    }
}
