import java.util.ArrayList;
import java.util.List;

class Estoque {
    private List<Produto> produtos;

    public Estoque() {
        this.produtos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public boolean verificarEstoque(Produto produto, int quantidade) {
        for (Produto p : produtos) {
            if (p.getNome().equals(produto.getNome()) && p.getQuantidade() >= quantidade) {
                return true;
            }
        }
        return false;
    }

    public void atualizarEstoque(Produto produto, int quantidade) {
        for (Produto p : produtos) {
            if (p.getNome().equals(produto.getNome())) {
                p.setQuantidade(p.getQuantidade() - quantidade);
            }
        }
    }

    public List<Produto> getProdutos() {
        return produtos;
    }
}



