import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaCarrinho extends JFrame {
    private Carrinho carrinho;
    private Estoque estoque;

    public TelaCarrinho(Carrinho carrinho, Estoque estoque) {
        this.carrinho = carrinho;
        this.estoque = estoque;

        setTitle("Carrinho de Compras");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Define esquema de cores
        Color backgroundColor = new Color(60, 63, 65);
        Color panelColor = new Color(43, 43, 43);
        Color textColor = new Color(187, 187, 187);
        Color buttonColor = new Color(75, 110, 175);
        Color buttonTextColor = Color.WHITE;

        // Configurações do título
        JLabel titulo = new JLabel("Carrinho de Compras", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(textColor);
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Configurações do painel de itens do carrinho
        JPanel panelItens = new JPanel();
        panelItens.setLayout(new GridLayout(0, 1, 10, 10));
        panelItens.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelItens.setBackground(backgroundColor);

        for (ItemVenda item : carrinho.getItens()) {
            JPanel panelItem = new JPanel(new BorderLayout());
            panelItem.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
            panelItem.setBackground(panelColor);

            JLabel labelNome = new JLabel(item.getProduto().getNome());
            labelNome.setHorizontalAlignment(SwingConstants.CENTER);
            labelNome.setFont(new Font("Arial", Font.BOLD, 14));
            labelNome.setForeground(textColor);
            panelItem.add(labelNome, BorderLayout.NORTH);

            JLabel labelQuantidade = new JLabel("Quantidade: " + item.getQuantidade());
            labelQuantidade.setHorizontalAlignment(SwingConstants.CENTER);
            labelQuantidade.setForeground(textColor);
            panelItem.add(labelQuantidade, BorderLayout.CENTER);

            JLabel labelPreco = new JLabel("Preço: R$ " + item.getTotal());
            labelPreco.setHorizontalAlignment(SwingConstants.CENTER);
            labelPreco.setForeground(textColor);
            panelItem.add(labelPreco, BorderLayout.SOUTH);

            panelItens.add(panelItem);
        }

        JScrollPane scrollPane = new JScrollPane(panelItens);
        add(scrollPane, BorderLayout.CENTER);

        // Configurações do painel de botões
        JPanel panelBotoes = new JPanel();
        panelBotoes.setLayout(new GridLayout(1, 2, 10, 10));
        panelBotoes.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelBotoes.setBackground(backgroundColor);

        JButton buttonVoltar = new JButton("Voltar");
        buttonVoltar.setBackground(buttonColor);
        buttonVoltar.setForeground(buttonTextColor);
        buttonVoltar.setFocusPainted(false);
        buttonVoltar.setBorder(BorderFactory.createLineBorder(buttonColor));
        buttonVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TelaPrincipal telaPrincipal = new TelaPrincipal(carrinho, estoque);
                telaPrincipal.setVisible(true);
                dispose();
            }
        });

        JButton buttonFinalizar = new JButton("Finalizar Compra");
        buttonFinalizar.setBackground(buttonColor);
        buttonFinalizar.setForeground(buttonTextColor);
        buttonFinalizar.setFocusPainted(false);
        buttonFinalizar.setBorder(BorderFactory.createLineBorder(buttonColor));
        buttonFinalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TelaPagamento telaPagamento = new TelaPagamento(carrinho, estoque);
                telaPagamento.setVisible(true);
                dispose();
            }
        });

        panelBotoes.add(buttonVoltar);
        panelBotoes.add(buttonFinalizar);

        add(panelBotoes, BorderLayout.SOUTH);

        // Define o background da tela principal
        JPanel backgroundPanel = new JPanel(new BorderLayout());
        backgroundPanel.setBackground(backgroundColor);
        backgroundPanel.add(titulo, BorderLayout.NORTH);
        backgroundPanel.add(scrollPane, BorderLayout.CENTER);
        backgroundPanel.add(panelBotoes, BorderLayout.SOUTH);

        add(backgroundPanel);

        // Centraliza a tela
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        // Código de teste para a TelaCarrinho
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Estoque estoque = new Estoque();
                Carrinho carrinho = new Carrinho();

                // Adiciona produtos de exemplo ao carrinho
                Produto produto1 = new Produto("Tinta Branca", 50.0, 10);
                Produto produto2 = new Produto("Tinta Preta", 45.0, 5);
                carrinho.adicionarItem(new ItemVenda(produto1, 2));
                carrinho.adicionarItem(new ItemVenda(produto2, 1));

                TelaCarrinho telaCarrinho = new TelaCarrinho(carrinho, estoque);
                telaCarrinho.setVisible(true);
            }
        });
    }
}

