import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPagamento extends JFrame {
    private Carrinho carrinho;
    private Estoque estoque;

    public TelaPagamento(Carrinho carrinho, Estoque estoque) {
        this.carrinho = carrinho;
        this.estoque = estoque;

        setTitle("Pagamento");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Define esquema de cores
        Color backgroundColor = new Color(60, 63, 65);
        Color panelColor = new Color(43, 43, 43);
        Color textColor = new Color(187, 187, 187);
        Color buttonColor = new Color(75, 110, 175);
        Color buttonTextColor = Color.WHITE;

        // Configurações do título
        JLabel titulo = new JLabel("Pagamento", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(textColor);
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Configurações do painel de pagamento
        JPanel panelPagamento = new JPanel();
        panelPagamento.setLayout(new GridLayout(5, 2, 10, 10));
        panelPagamento.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelPagamento.setBackground(backgroundColor);

        JLabel labelNome = new JLabel("Nome:");
        labelNome.setForeground(textColor);
        JTextField textFieldNome = new JTextField();
        textFieldNome.setBackground(panelColor);
        textFieldNome.setForeground(textColor);
        textFieldNome.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JLabel labelEndereco = new JLabel("Endereço:");
        labelEndereco.setForeground(textColor);
        JTextField textFieldEndereco = new JTextField();
        textFieldEndereco.setBackground(panelColor);
        textFieldEndereco.setForeground(textColor);
        textFieldEndereco.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JLabel labelFormaPagamento = new JLabel("Forma de Pagamento:");
        labelFormaPagamento.setForeground(textColor);
        String[] formasPagamento = {"Cartão de Crédito", "Boleto", "PIX"};
        JComboBox<String> comboBoxFormaPagamento = new JComboBox<>(formasPagamento);
        comboBoxFormaPagamento.setBackground(panelColor);
        comboBoxFormaPagamento.setForeground(textColor);
        comboBoxFormaPagamento.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JLabel labelTotal = new JLabel("Total: R$ " + carrinho.getTotal());
        labelTotal.setForeground(textColor);

        panelPagamento.add(labelNome);
        panelPagamento.add(textFieldNome);
        panelPagamento.add(labelEndereco);
        panelPagamento.add(textFieldEndereco);
        panelPagamento.add(labelFormaPagamento);
        panelPagamento.add(comboBoxFormaPagamento);
        panelPagamento.add(new JLabel()); // Placeholder
        panelPagamento.add(labelTotal);

        add(panelPagamento, BorderLayout.CENTER);

        // Configurações do botão de confirmar pagamento
        JButton buttonConfirmar = new JButton("Confirmar Pagamento");
        buttonConfirmar.setBackground(buttonColor);
        buttonConfirmar.setForeground(buttonTextColor);
        buttonConfirmar.setFocusPainted(false);
        buttonConfirmar.setBorder(BorderFactory.createLineBorder(buttonColor));
        buttonConfirmar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Verificar se todos os campos estão preenchidos
                if (textFieldNome.getText().isEmpty() || textFieldEndereco.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.");
                } else {
                    // Finalizar compra (lógica de finalização de compra)
                    FinalizandoCompra.finalizarCompra(carrinho, estoque);
                    JOptionPane.showMessageDialog(null, "Pagamento realizado com sucesso!");
                    TelaPrincipal telaPrincipal = new TelaPrincipal(new Carrinho(), estoque); // Novo carrinho para novas compras
                    telaPrincipal.setVisible(true);
                    dispose();
                }
            }
        });

        JPanel panelButton = new JPanel();
        panelButton.setLayout(new BorderLayout());
        panelButton.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelButton.setBackground(backgroundColor);
        panelButton.add(buttonConfirmar, BorderLayout.CENTER);

        add(panelButton, BorderLayout.SOUTH);

        // Define o background da tela principal
        JPanel backgroundPanel = new JPanel(new BorderLayout());
        backgroundPanel.setBackground(backgroundColor);
        backgroundPanel.add(titulo, BorderLayout.NORTH);
        backgroundPanel.add(panelPagamento, BorderLayout.CENTER);
        backgroundPanel.add(panelButton, BorderLayout.SOUTH);

        add(backgroundPanel);

        // Centraliza a tela
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        // Código de teste para a TelaPagamento
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Estoque estoque = new Estoque();
                Carrinho carrinho = new Carrinho();

                // Adiciona produtos de exemplo ao carrinho
                Produto produto1 = new Produto("Tinta Branca", 50.0, 10);
                Produto produto2 = new Produto("Tinta Preta", 45.0, 5);
                carrinho.adicionarItem(new ItemVenda(produto1, 2));
                carrinho.adicionarItem(new ItemVenda(produto2, 1));

                TelaPagamento telaPagamento = new TelaPagamento(carrinho, estoque);
                telaPagamento.setVisible(true);
            }
        });
    }
}



